import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './Components/dashboard/dashboard.component';
import { PageNotFountComponent } from './Components/page-not-fount/page-not-fount.component';
import { CustomerService } from './Services/customer.service';
// import { SidebarComponent } from './Components/sidebar/sidebar.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { FooterComponent } from './Components/footer/footer.component';
import { SharedModule } from './Modules/shared/shared.module';
import { SidebarComponent } from './Components/sidebar/sidebar.component';
// import { HeaderComponent } from './Components/header/header.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    PageNotFountComponent,
    // SidebarComponent,
    // HeaderComponent,
    FooterComponent,   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
     SharedModule
    
  ],
  exports:[],
  providers: [CustomerService,
    {provide:LocationStrategy,useClass:HashLocationStrategy}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
