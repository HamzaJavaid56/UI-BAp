import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { CustomerFeeReq } from '../Model/customer';

@Injectable({
  providedIn: 'root'
})
export class FeeService {
  
  api_url: string = environment.API_URL;

  constructor(private http: HttpClient) { }

  AddCustomerFee(R:CustomerFeeReq)
  {
    return this.http.post(this.api_url+'/Fee/AddCustomerFee',R)
  }

}
