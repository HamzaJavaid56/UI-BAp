import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MonthResponse, YearResponse } from '../Model/shared';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  api_url: string = environment.API_URL;

  constructor(private http: HttpClient) { }

  GetMonth():Observable<MonthResponse>
  {
    return this.http.get<MonthResponse>(this.api_url+'/Shared/GetMonth')
  }
  GetYear():Observable<YearResponse>
  {
    return this.http.get<YearResponse>(this.api_url+'/Shared/GetYear')

  }
}
