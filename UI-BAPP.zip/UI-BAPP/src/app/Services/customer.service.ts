import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Town } from '../Model/city';
import { CustomerResponse, CustomerResquest } from '../Model/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  api_url: string = environment.API_URL;

  constructor(private http: HttpClient) { }

  GetCustomer():Observable<CustomerResponse>
  {
    return this.http.get<CustomerResponse>(this.api_url+'/Customer/GetCustomer')
  }
  GetCustomerByCeiteria(RQ):Observable<CustomerResponse>
  {
    return this.http.post<CustomerResponse>(this.api_url+'/Customer/GetCustomerByCeiteria',RQ)
  }

  SetCustomer(R:CustomerResquest)
  {
    return this.http.post(this.api_url+'/Customer/SetCustomer',R)
  }

  GetCustomerById(R:CustomerResquest)
  {
    return this.http.post(this.api_url+'/Customer/GetCustomerById',R)
  }
  
  
}
