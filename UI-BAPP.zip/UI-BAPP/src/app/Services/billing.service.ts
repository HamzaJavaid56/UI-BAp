import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { BillGenerationRequest, BillRequest, BillResponse } from '../Model/bill';
import { CustomerResquest } from '../Model/customer';

@Injectable({
  providedIn: 'root'
})
export class BillingService {

  api_url: string = environment.API_URL;

  constructor(private http: HttpClient) {

  }
  GetCustomerBill(): Observable<BillResponse> {
    return this.http.get<BillResponse>(this.api_url + '/Billing/GetCustomerBill')
  }

  GetCustomerBillByCriteria(RQ): Observable<BillResponse> {
    return this.http.post<BillResponse>(this.api_url+'/Billing/GetCustomerBillByCriteria', RQ)
  }

  GenerateBillTownWise(RQ: BillGenerationRequest) {
    return this.http.post<BillResponse>(this.api_url+'/Billing/GenerateBillTownWise', RQ)

  }

  PostPaidBill(RQ) {
    return this.http.post<BillResponse>(this.api_url + '/Billing/PostPaidBill', RQ)
  }

  SetBillPayment(RQ) {
    return this.http.post<BillResponse>(this.api_url + '/Billing/SetBillPayment', RQ)
  }

  GetBillPayment() {
    return this.http.get(this.api_url + '/Billing/GetBillPayment')
  }

  GetBillPaymentByCriteria(RQ) {
    return this.http.post(this.api_url + '/Billing/GetBillPaymentByCriteria', RQ)
  }

  ExportToPDFBills(RQ): Observable<Blob> {
    return this.http.post(this.api_url + '/Billing/ExportToPDFBills', RQ, { responseType: 'blob' })
  }

  ExportToPDFLedger(RQ): Observable<Blob> {
    return this.http.post(this.api_url + '/Billing/ExportToPDFLedger', RQ, { responseType: 'blob' })
  }

}
