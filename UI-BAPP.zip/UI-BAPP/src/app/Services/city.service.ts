import { HttpClient } from '@angular/common/http';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Region, RegionRequest, Town, Townrequest } from '../Model/city';


@Injectable({
  providedIn: 'root'
})
export class CityService {

  api_url: string = environment.API_URL;

  constructor(private http: HttpClient) { }

  GetRegion(): Observable<Region> {
    return this.http.get<Region>(this.api_url + '/City/GetRegion')
  }

  GetTown(): Observable<Town> {
    return this.http.get<Town>(this.api_url +'/City/GetTown')
  }

  SetRegion(Rq: RegionRequest) {
    return this.http.post(this.api_url +'/City/SetRegion', Rq)
  }

  SetTown(Rq: Townrequest) {
    return this.http.post(this.api_url +'/City/SetTown', Rq)
  }

}
