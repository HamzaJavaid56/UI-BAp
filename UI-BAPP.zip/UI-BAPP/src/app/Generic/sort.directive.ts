import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';
import { sort } from './sort';


@Directive({
selector: '[appSort]'
})
export class SortDirective {

@Input() appSort:Array<any> | undefined;

constructor(private render:Renderer2,private targetElem: ElementRef) { }
@HostListener("click")

sortData()
{
const Sort =new sort();
const elem = this.targetElem.nativeElement;
const order = elem.getAttribute("data-order")
const type= elem.getAttribute("data-type")
const property= elem.getAttribute("data-name")
if(order==="desc")
{
this.appSort?.sort(Sort.startSort(property,order,type))
elem.setAttribute("data-order","asc")
}
else{
this.appSort?.sort(Sort.startSort(property,order,type))
elem.setAttribute("data-order","desc")
}
}


}
 