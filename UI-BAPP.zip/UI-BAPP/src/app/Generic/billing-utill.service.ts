import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BillingUtillService {
  headers: HttpHeaders;
  static filteredColumns: any[];
  constructor(public http: HttpClient)
  {
  this.headers = this.getHeaders();
  }
  
  GenericServiceCallMethod(callType?: string, URL?: string, token?: string, data?: any): any {
  if (callType != "" && URL!="" ) {
  // MAKING COMPLETE URL , SETTING CALL TYPE [POST / GET] AND MAKING HEADERS
  let myUrl=""
  let requestUrl=""
  myUrl="http://localhost:63061/api/"
  requestUrl=myUrl+URL
  this.headers = this.headers.set('Request-Date', new Date().toLocaleString());
  if (callType == "post") {
  if (data != null) {
  return this.http.post(requestUrl, data, { headers: this.headers })
  }
  else {
  return JSON.stringify("Please send data");
  }
  }
  else if (callType == "get") {
  return this.http.get(requestUrl, { responseType: 'text', headers: this.headers })
  }
  else {
  return JSON.stringify("Please enter a valid call type [post get]");
  }
  } else {
  return JSON.stringify("Controler/Action name or type [post get] required");
  }
  }
  private getHeaders() {
  let headers = new HttpHeaders();
  headers = headers.append('Access-Control-Allow-Origin', '*');
  headers = headers.append("Access-Control-Allow-Credentials", "true");
  headers = headers.append('Access-Control-Allow-Headers', '*');
  // headers = headers.append('Token', localStorage.getItem("AuthToken"));
  // headers = headers.append('serverID', localStorage.getItem("siteId"));
  headers = headers.append('Content-Type', 'application/json; charset=UTF-8');
  headers = headers.append('Accept', 'application/json');
  headers = headers.append('Request-Date', new Date().toLocaleString())
  return headers;
  }
  
  //Added for the Demographics
  static setFilterColumns(columns: any = []) {
  this.filteredColumns = [];
  if (columns != null && columns != undefined && columns.length > 0) {
  for (var i = 0; i < columns.length; i++) {
  this.filteredColumns.push(columns[i]);
  }
  }
  }
  }