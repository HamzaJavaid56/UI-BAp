import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AfUtillService {

  api_url: string = environment.API_URL;
  constructor(private http: HttpClient) { }


  userAuthentication(userName:any, password:any) {
    var data = "username=" + userName + "&password=" + password + "&grant_type=password";
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/x-www-urlencoded','No-Auth':'True' });
    return this.http.post('http://localhost:10203/'+ 'token', data, { headers: reqHeader });
    
    }
}
