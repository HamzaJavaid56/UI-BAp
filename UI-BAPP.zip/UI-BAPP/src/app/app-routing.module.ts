import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './Components/dashboard/dashboard.component';
import { PageNotFountComponent } from './Components/page-not-fount/page-not-fount.component';
import { AuthGuard } from './Guards/auth-guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },

  {
    path: 'dashboard',
    component: DashboardComponent 
     ,canActivate:[AuthGuard]
  },
 
  {
    path: 'login', loadChildren: () => import('./Modules/Login/login.module').then(m => m.LoginModule)
  },

  {
    path: 'customers', loadChildren: () => import('./Modules/customer/customer.module').then(m => m.CustomerModule) ,canActivate:[AuthGuard] 
  },
  {
    path: 'bill', loadChildren: () => import('./Modules/bill/bill.module').then(m => m.BillModule) ,canActivate:[AuthGuard]
  },

  {
    path: 'report', loadChildren: () => import('./Modules/report/report.module').then(m => m.ReportModule) ,canActivate:[AuthGuard]
   },
 

  {
    path: 'city', loadChildren: () => import('./Modules/city/city.module').then(m => m.CityModule) ,canActivate:[AuthGuard]
  },
  {
    path: '*', component: PageNotFountComponent
  },





];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
