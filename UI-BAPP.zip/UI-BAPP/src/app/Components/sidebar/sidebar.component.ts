import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  constructor(

    private router : Router,
  ) { }

  ngOnInit(): void {
  }
  NavigateRoute(dashboard:String)
  {
   
   if(dashboard=='dashboard')
   {

    this.router.navigateByUrl('dashboard' );
   }
   else if(dashboard=='customers')
   {
    this.router.navigateByUrl('customers' );
   }
   else if(dashboard=='city')
   {
    this.router.navigateByUrl('city' );
   }
   else if(dashboard=='bill_inquiry')
   {
    this.router.navigateByUrl('bill' );
   }
   else if(dashboard=='report')
   {
    this.router.navigateByUrl('report' );
   }
   
 


  }


}
