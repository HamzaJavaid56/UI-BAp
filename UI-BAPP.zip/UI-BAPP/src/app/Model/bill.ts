import { ThrowStmt } from "@angular/compiler"

export class BillResponse {
    bill_id: number
    customer_id: number
    monthly_fee: number
    due_amount: number
    total_bill_amount: number
    bill_month: string
    bill_year:string
    bill_created_date: number
    created_by: number
    modified_date: number
    modified_by: number
    payment_id:number
}
export class BillRequest {
    customer_id:string
    bill_year:string
    bill_month:string
    town_name:string
    region_name:string

    constructor()
    {
        this.bill_year='All'
        this.bill_month='All'
        this.town_name='All'
        this.region_name='All'
    }
}

export class BillGenerationRequest
{
    customer_id: number
    bill_year:string
    bill_month:string
    customer_name: string
    town_id: string
    region_id:string
    region_name:string
    // father_name: string
    // cinic: string
    // Is_active: boolean
    // phone1: string
    // phone2: string
    // address: string
    // emailid: string
    // created_date: string
    // created_by: string
    // town_id: number
    // town_name:string
    // billing_address: string
    // connection_date: string
    // joindate:string
    // bill_month:string
   
}


export class BillPaymentResponse {
    payment_id:number
    bill_id: number
    is_paid: boolean
    total_bill_amount: number
    paid_amount: number
    remaining_due_amount: number
    paid_date: string
    created_by: string
    modified_date: string
    modified_by: string
    bill_month :string
    bill_year:string
    customer_name :string
    customer_id :number
}
export class BillPaymentRequest{
    payment_id: number
    bill_id: number
    paid_amount: number
    
}