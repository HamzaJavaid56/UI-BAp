export class Region{
    region_id:string
    region_name:string

}

export class RegionRequest{
    region_id:string
    region_name:string
    operation:string
}


export class Town {
    town_id: string
    town_name: string
    region_id: number
    region_name:string

}

export class Townrequest {
    town_id: string
    town_name: string
    region_id: number
    region_name:string
    operation:string
}
