export class MonthRequest{
    month_id:number
    month_name:string
}

export class YearRequest{
    year_id:number
    year_name:string
}
  
export class MonthResponse{
    month_id:number
    month_name:string
}

export class YearResponse{
    year_id:number
    year_name:string
}
  