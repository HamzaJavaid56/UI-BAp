export class CustomerResponse {
      customer_id: number
      customer_name: string
      father_name: string
      home_owner: string
      cinic: string
      is_active: boolean
      phone1: string
      phone2: string
      address: string
      emailid: string
      created_date: string
      created_by: string
      billing_address: string
      connection_date: string
      joindate:string
      bill_month:string
      town_id: string
      town_name:string
      region_id:string
      region_name:string
      urdu_name:string
      monthly_fee:number

}


export class CustomerResquest {
      customer_id: number;
      customer_name: string
      father_name: string
      home_owner: string
      cinic: string
      is_active :boolean
      phone1: string
      phone2: string
      address: string
      emailid: string
      created_by: string
      connection_date: string
      action: string
      joindate:string        
      town_id: string
      town_name:string
      region_id:string
      region_name:string
      urdu_name :string  
      monthly_fee:number | undefined
      connection_fee:number | undefined
      billing_address :string


      constructor()
      {
      this.town_id='All'
      this.region_id='All'
      this.is_active=true
      }
     
      
}

export class timeframe{
      bill_year:string
      bill_month:string
      
}


export class CustomerFeeReq {
      customer_id:number
      connection_fee :number
      monthly_fee:number
      discount_amount:number
      total_monthly_fee:number

      // fee_id: number
      // fee_type: string
      // fee_amount: number
      // created_date: string
      // created_by: string

}
