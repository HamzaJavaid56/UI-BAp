import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Town } from 'src/app/Model/city';
import { CustomerResquest } from 'src/app/Model/customer';
import { CityService } from 'src/app/Services/city.service';
import { CustomerService } from 'src/app/Services/customer.service';

@Component({
  selector: 'app-customerform',
  templateUrl: './customerform.component.html',
  styleUrls: ['./customerform.component.css']
})
export class CustomerformComponent implements OnInit {

  R : CustomerResquest;
  objTown: Town[];
  objTown2: Town;
  townID : any;
  
  @ViewChild('customerForm') f: NgForm | any
  constructor(
  private _CustomerService: CustomerService,
  private _CityService:CityService,
  private router:Router,
  private activatedRoute:ActivatedRoute
  ) {
  this.R=new CustomerResquest()
  this.objTown=[];
  //console.log(this.router.getCurrentNavigation().extras.state);
  this.objTown2=new Town();
  }
  
  
  ngOnInit() {
  this.R=history.state;
  console.log(this.R )
  this.GetTown();
  }
  
  OnSubmitForm()
  {
  console.log(this.f)
  this.R=this.f.value
  this.SetCustomer(this.R);
  }
  
  
  SetCustomer(R:CustomerResquest)
  {
  //R.town_id=this.objTown2.town_id;
  console.log( R.town_id)
  if(R.customer_id>0)
  {
  R.action='update'
  }
  else{
  R.action='insert'
  }
  this._CustomerService.SetCustomer(R).subscribe(data=>{
  console.log(data)
  alert(data)

  })
  console.warn(R)
  }
  
  GetTown()
  {
  this._CityService.GetTown().subscribe(data=>{
  this.objTown=JSON.parse(JSON.stringify( data))
  //this.objTown2=data;
  })
  }
  // changeTown(e:any) {
  // this.objTown2.town_id=e.target.value;
  // // console.log(this.objTown2.town_id);
  // }
  
  resetForm(customerForm:NgForm)
  {
  customerForm.resetForm();
  }
  
  
  
  }

 