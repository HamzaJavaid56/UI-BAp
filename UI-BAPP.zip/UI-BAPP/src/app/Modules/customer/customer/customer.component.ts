import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CustomerResponse, CustomerResquest } from 'src/app/Model/customer';
import { CustomerService } from 'src/app/Services/customer.service';
import { NgForm } from '@angular/forms';
import { PagerService } from 'src/app/Generic/pager.service';
import { ThrowStmt } from '@angular/compiler';
import { Region, Town } from 'src/app/Model/city';
import { CityService } from 'src/app/Services/city.service';
// import {SortDirective} from '../../../Generic/sort.directive'
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

page: any ;
pager: any={}
pagesize: number = 50;
totalpages: string = "1";
dataset: any[] = [];
objCustomerResponseOrignal: CustomerResponse[]
objCustomerResponse: CustomerResponse[]
objCustomerResponse2: CustomerResponse[];
RQ_CustomerResquest: CustomerResquest
RS_Region:Region[]
RS_Town: Town[]
dataset2: any[] = [];
query:any
customer_count:number
town_count:number
region_count:number
showLoader:boolean=false
constructor(
private _CustomerService :CustomerService,
private _CityService:CityService,
private router : Router,
private pagerService: PagerService,
) {
this.objCustomerResponseOrignal=[]
this.objCustomerResponse=[]
this.objCustomerResponse2=[]
this.RQ_CustomerResquest=new CustomerResquest()
this.RS_Town=[];
this.RS_Region=[];
}
ngOnInit(): void {
//this.GetCustomer()

  this.GetRegion()
  this.GetTown()
  // this.RQ_CustomerResquest.region_id='All'
  // this.RQ_CustomerResquest.town_id='All'
  
}

GetCustomer()
{
this._CustomerService.GetCustomer().subscribe(data=>{
if(data)
{
this.objCustomerResponseOrignal=JSON.parse(JSON.stringify(data))
this.customer_count=this.objCustomerResponseOrignal.length;

}
else{
this.objCustomerResponseOrignal=[]

}
})
setTimeout(() =>
this.objCustomerResponse=this.objCustomerResponseOrignal, 1000);
// setTimeout(() =>
// this.setPage(1,50), 1000);
}

GetCustomerByCeiteria(RQ:CustomerResquest)
{

  this.showLoader=true
  this._CustomerService.GetCustomerByCeiteria(RQ).subscribe(data=>{
    if(data)
    {
      this.showLoader=false
    this.objCustomerResponseOrignal=JSON.parse(JSON.stringify(data))
    this.customer_count=this.objCustomerResponseOrignal.length;
    setTimeout(() => {
      this.setPage(1,this.pagesize)
      }, 20);
    }
    else{
    this.objCustomerResponseOrignal=[]
    
    }
    })
}

GetRegion()
  {
  
    this._CityService.GetRegion().subscribe(data=>{
         this.RS_Region= JSON.parse(JSON.stringify(data))
         this.region_count=this.RS_Region.length
    })
  }

  GetTown() {
    this._CityService.GetTown().subscribe(data => {

      this.RS_Town = JSON.parse(JSON.stringify(data)) 
      this.town_count=this.RS_Town.length;
    })

  }

UpdateCustomer(R:any)
{
console.warn(R)
this.router.navigateByUrl('customers/customerForm', { state: R });
}

AddCustomerFee(R:any)
{
console.warn(R)
this.router.navigateByUrl('customers/customerFee', { state: R });
}

setPage(pages: any, pagesize: any ) {

if ((pages < 1 || pages > this.pager.totalPages) && pages != "") {
this.page = 1;
pages = 1;
}
this.page = pages;
//get pager object from service
this.pager = this.pagerService.getPager(this.objCustomerResponseOrignal.length, pages, pagesize);
// get current page of items
this.objCustomerResponse = this.objCustomerResponseOrignal.slice(this.pager.startIndex, this.pager.endIndex + 1);
}

 ShowLoader() {
  document.getElementById("overlay").style.display = "block";
}



}
