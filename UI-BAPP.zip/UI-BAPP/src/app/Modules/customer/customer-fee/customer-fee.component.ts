import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CustomerFeeReq } from 'src/app/Model/customer';
import { FeeService } from 'src/app/Services/fee.service';

@Component({
  selector: 'app-customer-fee',
  templateUrl: './customer-fee.component.html',
  styleUrls: ['./customer-fee.component.css']
})
export class CustomerFeeComponent implements OnInit {

 
Rq_CustomerFee: CustomerFeeReq
Total:any;
constructor(private _FeeService :FeeService) {
this.Rq_CustomerFee=new CustomerFeeReq();
}

ngOnInit(): void {
this.Rq_CustomerFee=history.state
//this.Rq_CustomerFee.customer_id=history.state;
//console.log("Customer_Id"+ history.state );
}
AddCustomerFee(FeeForm:NgForm)
{
console.warn(FeeForm.value)
this.Rq_CustomerFee=FeeForm.value;
this._FeeService.AddCustomerFee(this.Rq_CustomerFee).subscribe(data=>{
console.log(data)
})
}


}
