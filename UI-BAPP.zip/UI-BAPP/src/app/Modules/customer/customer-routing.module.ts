import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerAddComponent } from './customer-add/customer-add.component';
import { CustomerFeeComponent } from './customer-fee/customer-fee.component';
import { CustomerComponent } from './customer/customer.component';
import { CustomerformComponent } from './customerform/customerform.component';

const routes: Routes = [

  // {
  //   path:'',
  //   redirectTo:'customer',
  //   // pathMatch:'full'
  // },
  { 
    path: '', 
    component :CustomerComponent
  },

  { 
    path: 'customerForm', 
    component :CustomerformComponent
  },
{
  path:'customerAdd',
  component:CustomerAddComponent
},
{
  path:'customerFee',
  component:CustomerFeeComponent
}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerRoutingModule { }
