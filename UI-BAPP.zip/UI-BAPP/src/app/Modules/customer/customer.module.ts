import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerComponent } from './customer/customer.component';
import { CustomerformComponent } from './customerform/customerform.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomerAddComponent } from './customer-add/customer-add.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomerFeeComponent } from './customer-fee/customer-fee.component';
import { SortDirective } from 'src/app/Generic/sort.directive';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    CustomerComponent,
    CustomerformComponent,
    CustomerAddComponent,
    CustomerFeeComponent,
    SortDirective,
    
    
  ],
  imports: [
    CommonModule,
    CustomerRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    SharedModule
  ]
})
export class CustomerModule { }
