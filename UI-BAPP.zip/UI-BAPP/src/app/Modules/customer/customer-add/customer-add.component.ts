import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Town } from 'src/app/Model/city';
import { CustomerResquest } from 'src/app/Model/customer';
import { CityService } from 'src/app/Services/city.service';
import { CustomerService } from 'src/app/Services/customer.service';

@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.css']
})
export class CustomerAddComponent implements OnInit {


  R: CustomerResquest;
  objTown: Town
  townId: any;
  selectValue: any
  model;

  constructor(
    private _customerservice: CustomerService,
    private _CityService:CityService,
    private router: Router,
    private activatedRoute: ActivatedRoute) {
    this.R = new CustomerResquest();
    console.log(this.router.getCurrentNavigation().extras.state);
  }

  ngOnInit(): void {

    this.R = history.state;
    this.GetTown();
  }

  // onSubmit(CustomerForm)
  // {
  //  //console.warn(CustomerForm )
  //  this.SetCustomer(CustomerForm.value);
  //  //CustomerForm.reset();
  // }

  SetCustomer(R: CustomerResquest) {


    console.warn(R)
    //console.log(this.SelectTown())

    if (R.customer_id < 0 || R.customer_id == null) {
      alert('Insert   ' + this.R.customer_id);
      this.R.action = "Insert";

    }

    else if (this.R.customer_id > 0) {
      alert('update   ' + this.R.customer_id);

      this.R.action = "update"

    }

    this._customerservice.SetCustomer(this.R).subscribe(data => {
   alert(data)
    })
  }

  GetTown() {
    this._CityService.GetTown().subscribe(data => {

      this.objTown = data;
    })
  }

  SelectTown(e?: any) {
    console.log(e.target.value)
    this.townId = (e.target.value)
    //return (e.target.value)
  }

  ResetForm(CustomerForm: NgForm) {
    CustomerForm.resetForm
  }

}
