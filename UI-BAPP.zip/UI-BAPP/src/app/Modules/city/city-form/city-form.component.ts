import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RegionRequest } from 'src/app/Model/city';
import { CityService } from 'src/app/Services/city.service';

@Component({
  selector: 'app-city-form',
  templateUrl: './city-form.component.html',
  styleUrls: ['./city-form.component.css']
})
export class CityFormComponent implements OnInit {

  Rq: RegionRequest

  constructor(private _CityService: CityService) {
    this.Rq = new RegionRequest()
  }

  ngOnInit(): void {
    this.Rq=history.state
  }

  SetRegion(Rq: NgForm) {
    this.Rq = Rq.value
    if (this.Rq.region_id ==null || this.Rq.region_id ==undefined ) {
       this.Rq.operation='Insert';
    }
    else if(this.Rq.region_id !=null || this.Rq.region_id !=undefined) {
      this.Rq.operation='Update';
     
    }
    else{
alert('Region Not Specify')
    }
    console.log(this.Rq)
    this._CityService.SetRegion(this.Rq).subscribe(data => {
      alert(data)
    })
  }

}
