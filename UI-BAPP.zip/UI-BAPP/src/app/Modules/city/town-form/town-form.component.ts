import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Region, Town, Townrequest } from 'src/app/Model/city';
import { CityService } from 'src/app/Services/city.service';
import { CustomerService } from 'src/app/Services/customer.service';

@Component({
  selector: 'app-town-form',
  templateUrl: './town-form.component.html',
  styleUrls: ['./town-form.component.css']
})
export class TownFormComponent implements OnInit {
  RS_Region:Region
  RQ_Town:Townrequest
  City:any

  constructor(
    private _CityService:CityService,
    private _CustomerService: CustomerService

  ) {
    
    this.RQ_Town=new Townrequest()
   }

  ngOnInit(): void {
    this.GetRegion()
    this.RQ_Town=history.state;
    
  }
  GetRegion()
  {
    this._CityService.GetRegion().subscribe(data=>{
         this.RS_Region=data
    })
  }

 
  OnSubmitForm(f:NgForm)
  {
    console.log(f.value)
    this.SetTown(f.value)
  }

  SetTown(Rq:Townrequest)
  {
    console.log(Rq)
    if(Rq.town_id==null || Rq.town_id==undefined )
    {
       Rq.operation="Insert"
    }
    else if(Rq.town_id!=null || Rq.town_id!=undefined )
    {
      Rq.operation="Update"
    }
    else{
      alert('Town Id Not Specify')
    
    }

    this._CityService.SetTown(Rq).subscribe(data=>{
      alert(data)
    })
  }


}
