import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CityRoutingModule } from './city-routing.module';
import { CityComponent } from './city/city.component';
import { TownComponent } from './town/town.component';
import { TownFormComponent } from './town-form/town-form.component';
import { CityFormComponent } from './city-form/city-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [CityComponent, TownComponent, TownFormComponent, CityFormComponent],
  imports: [
    CommonModule,
    CityRoutingModule,
    FormsModule,
    ReactiveFormsModule,
     SharedModule,
    // AppRoutingModule
  ]
})
export class CityModule { }
