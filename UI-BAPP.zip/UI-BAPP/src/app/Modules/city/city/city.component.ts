import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Region, Town } from 'src/app/Model/city';
import { CityService } from 'src/app/Services/city.service';

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent implements OnInit {

  constructor(
              private _CityService:CityService,
              private route: Router
              ) { }
 Rs_Region:Region
 Rs_Town :Town
  ngOnInit(): void {
    this.GetRegion()
    this.GetTown()
  }

  GetRegion()
  {
    this._CityService.GetRegion().subscribe(data=>{
         this.Rs_Region=data
    })
  }
  GetTown()
  {
    this._CityService.GetTown().subscribe(data=>{

      this.Rs_Town=data
    })
  }
  SetRegion(Rs)
  {
console.log(Rs)
 this.route.navigateByUrl('city/city-form',{state:Rs})
  }
  SetTown(R)
  {
    this.route.navigateByUrl('city/town-form', { state: R });
  }
}
