import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-town',
  templateUrl: './town.component.html',
  styleUrls: ['./town.component.css']
})
export class TownComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
