import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CityFormComponent } from './city-form/city-form.component';
import { CityComponent } from './city/city.component';
import { TownFormComponent } from './town-form/town-form.component';
import { TownComponent } from './town/town.component';

const routes: Routes = [
{
  path:'',
  component:CityComponent
},
{
  path:'city-form',
  component:CityFormComponent
},
{
  path:'town',
  component:TownComponent
},
{
  path:'town-form',
  component:TownFormComponent
}


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CityRoutingModule { }
