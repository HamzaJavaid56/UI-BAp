import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HighlightPipe } from 'src/app/Pipes/highlight.pipe';
import { FilterPipe } from 'src/app/Pipes/filter.pipe';
import { HeaderComponent } from 'src/app/Components/header/header.component';
import { SidebarComponent } from 'src/app/Components/sidebar/sidebar.component';
import { RouterModule } from '@angular/router';


@NgModule({
  declarations: [
    FilterPipe,
    HighlightPipe,
    HeaderComponent,
    SidebarComponent
    
  ],
  imports: [
    CommonModule,
    RouterModule,
 
   
  ],
  exports:[
    FilterPipe,
    HighlightPipe,
    HeaderComponent,
    SidebarComponent,
  
   
  ]

})
export class SharedModule { }
