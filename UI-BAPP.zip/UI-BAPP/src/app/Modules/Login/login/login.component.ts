import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AfUtillService } from 'src/app/Generic/af-utill.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user_name: any;
  user_password: any;
  isLoginError: boolean;
  error_mesasge:string;

  constructor( 
               private _AfUtillService :AfUtillService,
               private router:Router
               ) { }

  ngOnInit(): void {
  }

  OnSubmitForm(Login : NgForm)
{
  console.warn(Login.value)
 
  console.log('user name= '+ Login.value.user_name + ' Passowrd = '+Login.value.user_password)
  
this._AfUtillService.userAuthentication(this.user_name,this.user_password).subscribe((data : any)=>{
localStorage.setItem('userToken',data.access_token);
this.router.navigate(['/dashboard']);
},
(err : HttpErrorResponse)=>{
this.isLoginError = true;
this.error_mesasge="Incorrect User Name  or Password !!!";
});
}

//*******  Nedd to Replace with JWT token base authentication *****/

TemporaryLogin(Login : NgForm)
{
  console.log('user name= '+ Login.value.user_name + ' Passowrd = '+Login.value.user_password)
if(Login.value.user_name=='hamza' && Login.value.user_password=='Libra@123')
{
  localStorage.setItem('userToken','123456789');
  this.router.navigate(['/dashboard']);
}
else{
  this.error_mesasge="! Incorrect User Name  or Password ";
}
}




}
