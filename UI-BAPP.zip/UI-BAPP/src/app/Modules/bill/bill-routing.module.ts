import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { combineLatest } from 'rxjs';
import { BillGenerationComponent } from './bill-generation/bill-generation.component';
import { BillPaymentFormComponent } from './bill-payment-form/bill-payment-form.component';
import { BillPaymentComponent } from './bill-payment/bill-payment.component';
import { BillPrintComponent } from './bill-print/bill-print.component';
import { BillComponent } from './bill/bill.component';

const routes: Routes = 
[
 {  
   path:'' , 
   component: BillComponent
  },
  {
path:'bill-generation',
component:BillGenerationComponent
  },
  {
    path:'bill-payment',
    component:BillPaymentComponent
  },
  {
    path:'bill-payment-form',
    component:BillPaymentFormComponent
  },
  {
    path:'print-bill',
    component:BillPrintComponent
    
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BillRoutingModule { }
