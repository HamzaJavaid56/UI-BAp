import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { BillRequest, BillResponse } from 'src/app/Model/bill';
import { Region, Town, Townrequest } from 'src/app/Model/city';
import { CustomerResquest } from 'src/app/Model/customer';
import { MonthRequest, MonthResponse, YearRequest, YearResponse } from 'src/app/Model/shared';

import { BillingService } from 'src/app/Services/billing.service';
import { CityService } from 'src/app/Services/city.service';
import { CustomerService } from 'src/app/Services/customer.service';
import { SharedService } from 'src/app/Services/shared.service';

import * as FileSaver from 'file-saver';
import { Observable } from 'rxjs';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { PagerService } from 'src/app/Generic/pager.service';


@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {


  RS_BillResponseOrignal: BillResponse[]
  RS_BillResponse: BillResponse[]
  RQ_CustomerResquest: CustomerResquest
  Rs_BillResponseArray: BillResponse[]
  RS_Town: Town
  RS_Region: Region
  RQ_Town: Townrequest
  RQ_Month: MonthRequest
  RS_Month: MonthResponse
  RQ_Year: YearRequest
  RS_Year: YearResponse
  RQ_Bill: BillRequest

  is_postpaid: boolean
  customer_bill_count: number

  page: any;
  pager: any = {}
  pagesize: number = 50;
  totalpages: string = "1";
  query: any
  showLoader:boolean=false

  constructor(
    private _BillingService: BillingService,
    private router: Router,
    private _CustomerService: CustomerService,
    private _CityService: CityService,
    private _SharedService: SharedService,
    private pagerService: PagerService,
  ) {
    this.RQ_CustomerResquest = new CustomerResquest();
    this.RQ_Town = new Townrequest()
    this.RQ_Bill = new BillRequest()
    this.Rs_BillResponseArray = []
  }

  ngOnInit(): void {
    //this.GetCustomerBill();
    this.GetRegion();
    this.GetTown();
    this.GetMonth();
    this.GetYear()

  }

  GetCustomerBill() {
    
    this._BillingService.GetCustomerBill().subscribe(data => {
      this.RS_BillResponse = JSON.parse(JSON.stringify(data));
    })
  }

   

  GetCustomerBillByCriteria(RQ: BillRequest) {
    this.showLoader=true
    this._BillingService.GetCustomerBillByCriteria(RQ).subscribe(data => {
      if (data) {
        this.showLoader=false
        this.RS_BillResponseOrignal = JSON.parse(JSON.stringify(data));
        this.customer_bill_count = this.RS_BillResponseOrignal.length
        setTimeout(() => {
          this.setPage(1, this.pagesize)
        }, 20);
      }
      else {
        this.RS_BillResponseOrignal = [];
      }

    })


  }

  PostPaidBill(RQ: BillRequest) {
    this.showLoader=true
    this._BillingService.PostPaidBill(RQ).subscribe(data => { 
      if(data){
      this.RS_BillResponse = JSON.parse(JSON.stringify(data))
      alert(data)
    }
    else{
      alert("Some Error Occure")
    }
    this.showLoader=false

    })
  }

  EnyetPayment(Rs: BillResponse) {

    this.router.navigateByUrl('bill/bill-payment-form', { state: Rs });

  }

  GetRegion() {

    this._CityService.GetRegion().subscribe(data => {
      this.RS_Region = data
    })
  }

  GetTown() {
    this._CityService.GetTown().subscribe(data => {

      this.RS_Town = data
    })
  }

  GetMonth() {
    this._SharedService.GetMonth().subscribe(data => {
      this.RS_Month = data
    })
  }

  GetYear() {
    this._SharedService.GetYear().subscribe(data => {
      this.RS_Year = data;
    })
  }

   //------------------------------
  //Print To Pdf Bills Front End
  //------------------------------

  PrintLedger() {
    let DATA = document.getElementById('subjectresult')!;
    html2canvas(DATA).then(canvas => {
      let fileWidth = 200;
      let fileHeight = canvas.height * fileWidth / canvas.width;
      const FILEURI = canvas.toDataURL('image/png')
      let PDF = new jsPDF('p', 'mm', 'a4');
      let positionX = 5;
      let positionY = 1;
      PDF.addImage(FILEURI, 'PNG', positionX, positionY, fileWidth, fileHeight,)
      PDF.save('angular-demo.pdf');
    });
  }

  PrintBills(RQ) {
    //  this.Rs_BillResponseArray= JSON.parse(JSON.stringify(RQ)) 
    //  this.Rs_BillResponseArray.forEach(element => {
    //});
    let bill_id: number = 1
    let DATA = document.getElementById('bill');
    html2canvas(DATA).then(canvas => {
      let fileWidth = 200;
      let fileHeight = canvas.height * fileWidth / canvas.width;
      const FILEURI = canvas.toDataURL('image/png')
      let PDF = new jsPDF('p', 'mm', 'a4');
      let positionX = 5;
      let positionY = 1;
      PDF.addImage(FILEURI, 'PNG', positionX, positionY, fileWidth, fileHeight,)
      PDF.save('Bill_ID(' + bill_id + ').pdf');
    });

  }
  //------------------------------
  //Print To Pdf Bills using API
  //------------------------------
  ExportToPDFBills(RQ: BillRequest) {
    // this.RQ_Bill.customer_id=RQ.customer_id;

    console.log(RQ)
    this._BillingService.ExportToPDFBills(RQ).subscribe(data => {
      FileSaver.saveAs(data, "Bill_" + RQ.region_name +"--"+ RQ.customer_id+"_.pdf");
    })
  }

  //------------------------------
  //Print To Pdf Ledger using API
  //------------------------------
  ExportToPDFLedger(RQ: BillRequest) {
    // this.RQ_Bill.customer_id=RQ.customer_id;

    console.log(RQ)
    this._BillingService.ExportToPDFLedger(RQ).subscribe(data => {
      FileSaver.saveAs(data, "ledger_" + RQ.town_name + "_.pdf");
    })
  }

  //------------------------------
  //       Pagination
  //------------------------------
  setPage(pages: any, pagesize: any) {

    if ((pages < 1 || pages > this.pager.totalPages) && pages != "") {
      this.page = 1;
      pages = 1;
    }
    this.page = pages;
    //get pager object from service
    this.pager = this.pagerService.getPager(this.RS_BillResponseOrignal.length, pages, pagesize);
    // get current page of items
    this.RS_BillResponse = this.RS_BillResponseOrignal.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }
}
