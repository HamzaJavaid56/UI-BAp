import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BillPaymentRequest, BillPaymentResponse, BillResponse } from 'src/app/Model/bill';
import { BillingService } from 'src/app/Services/billing.service';

@Component({
  selector: 'app-bill-payment-form',
  templateUrl: './bill-payment-form.component.html',
  styleUrls: ['./bill-payment-form.component.css']
})
export class BillPaymentFormComponent implements OnInit {

  // Rs_BillResponse:  BillResponse
  RS_BillPaymentResponse:BillPaymentResponse
  RS_BillPaymentRequest:BillPaymentRequest
  
  constructor(
    private router:Router, 
    private activatedRoute:ActivatedRoute,
    private _BillingService:BillingService
  ) {
    // this.Rs_BillResponse=new BillResponse();
    this.RS_BillPaymentResponse=new BillPaymentResponse();
    console.log(this.router.getCurrentNavigation().extras.state);
    this.RS_BillPaymentResponse=history.state;
    
   }


  ngOnInit(): void {
   // this.Rs_BillResponse=history.state;

  }

  SetBillPayment(R:NgForm)
  {
    
    this.RS_BillPaymentRequest=R.value
    console.log(this.RS_BillPaymentRequest)

    this._BillingService.SetBillPayment(R.value).subscribe(data=>{
      alert(data)
    })
  }


}
