import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BillRoutingModule } from './bill-routing.module';
import { BillComponent } from './bill/bill.component';
import { BillPaymentComponent } from './bill-payment/bill-payment.component';
import { BillPaymentFormComponent } from './bill-payment-form/bill-payment-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BillGenerationComponent } from './bill-generation/bill-generation.component';
import { BillPrintComponent } from './bill-print/bill-print.component';
import { SharedModule } from '../shared/shared.module';



@NgModule({
  declarations: [
     BillComponent,
     BillPaymentComponent,
     BillPaymentFormComponent, 
     BillGenerationComponent,
     BillPrintComponent,
    ],
  imports: [
    CommonModule,
    BillRoutingModule,
    FormsModule,
    ReactiveFormsModule,
     SharedModule

  ]
})
export class BillModule { }
