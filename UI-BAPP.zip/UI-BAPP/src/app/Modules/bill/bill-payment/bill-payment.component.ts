import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PagerService } from 'src/app/Generic/pager.service';
import { BillPaymentResponse, BillRequest } from 'src/app/Model/bill';
import { Region, Town, Townrequest } from 'src/app/Model/city';
import { MonthRequest, MonthResponse, YearRequest, YearResponse } from 'src/app/Model/shared';
import { BillingService } from 'src/app/Services/billing.service';
import { CityService } from 'src/app/Services/city.service';
import { SharedService } from 'src/app/Services/shared.service';

@Component({
  selector: 'app-bill-payment',
  templateUrl: './bill-payment.component.html',
  styleUrls: ['./bill-payment.component.css']
})
export class BillPaymentComponent implements OnInit {

  RS_BillPaymentResponse: BillPaymentResponse[]
  RS_BillPaymentResponseOrignal: BillPaymentResponse[]


  RS_Town: Town
  RS_Region: Region
  RQ_Town: Townrequest
  RQ_Month: MonthRequest
  RS_Month: MonthResponse
  RQ_Year: YearRequest
  RS_Year: YearResponse
  RQ_Bill: BillRequest
  customer_bill_count: number
  showLoader:boolean=false

  page: any;
  pager: any = {}
  pagesize: number = 50;
  totalpages: string = "1";
  query: any
  constructor(
    private _BillingService: BillingService,
    private _CityService: CityService,
    private _SharedService: SharedService,
    private router: Router,
    private pagerService: PagerService

  ) {
    this.RS_BillPaymentResponse = [];
    this.RS_BillPaymentResponseOrignal=[]
    this.RQ_Town = new Townrequest()
    this.RQ_Bill = new BillRequest()
  }

  ngOnInit(): void {
   // this.GetBillPayment()
    this.GetRegion();
    this.GetTown();
    this.GetMonth();
    this.GetYear()
  }


  GetRegion() {

    this._CityService.GetRegion().subscribe(data => {
      this.RS_Region = data
    })
  }

  GetTown() {
    this._CityService.GetTown().subscribe(data => {

      this.RS_Town = data
    })
  }

  GetMonth() {
    this._SharedService.GetMonth().subscribe(data => {
      this.RS_Month = data
    })
  }

  GetYear() {
    this._SharedService.GetYear().subscribe(data => {
      this.RS_Year = data;
    })
  }
  GetBillPayment() {
    this._BillingService.GetBillPayment().subscribe(data => {
      this.RS_BillPaymentResponseOrignal = JSON.parse(JSON.stringify(data))
    })
  }

  GetBillPaymentByCriteria(RQ: BillRequest) {
    this.showLoader=true

    this._BillingService.GetBillPaymentByCriteria(RQ).subscribe(data => {
      if (data) {
        this.showLoader=false
      this.RS_BillPaymentResponseOrignal = JSON.parse(JSON.stringify(data))
      this.customer_bill_count=this.RS_BillPaymentResponseOrignal.length;
      setTimeout(() => {
        this.setPage(1, this.pagesize)
      }, 20);
      }
      else {
        this.RS_BillPaymentResponseOrignal = [];
      }
    })
    
  

  }

  updatePyament(R) {
    console.warn(R)
    this.router.navigateByUrl('bill/bill-payment-form', { state: R });
  }

  setPage(pages: any, pagesize: any) {

    if ((pages < 1 || pages > this.pager.totalPages) && pages != "") {
      this.page = 1;
      pages = 1;
    }
    this.page = pages;
    //get pager object from service
    this.pager = this.pagerService.getPager(this.RS_BillPaymentResponseOrignal.length, pages, pagesize);
    // get current page of items
    this.RS_BillPaymentResponse = this.RS_BillPaymentResponseOrignal.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }
}
