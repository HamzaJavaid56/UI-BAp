import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BillResponse } from 'src/app/Model/bill';

import * as FileSaver from 'file-saver';
import { Observable } from 'rxjs';
//import * as XLSX from 'xlsx';
import { PagerService } from 'src/app/Generic/pager.service';

import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { BillingService } from 'src/app/Services/billing.service';



@Component({
  selector: 'app-bill-print',
  templateUrl: './bill-print.component.html',
  styleUrls: ['./bill-print.component.css']
})
export class BillPrintComponent implements OnInit {
  
  Rs_BillResponse: BillResponse
  Rs_BillResponsePrint :BillResponse[];

  bill_id:number
  obj$:object
  constructor( 
    private _BillingService: BillingService,
    private router:Router, 
    private activatedRoute:ActivatedRoute) { 
   
   this.Rs_BillResponse=new BillResponse();
   this.Rs_BillResponsePrint=[];
   
   // console.log(this.router.getCurrentNavigation().extras.state);
   
  }

  ngOnInit(): void {
   
   
this.Rs_BillResponsePrint.push(history.state)
   console.log(this.Rs_BillResponsePrint) 

  
    //this.openPDF();

//  setTimeout(() => {
//   this.openPDF()}, 1000);
  }

  // GetCustomerBill() {
  //   this._BillingService.GetCustomerBill().subscribe(data => {
  //     this.Rs_BillResponsePrint =JSON.parse(JSON.stringify(data));
  //   })
  // }

  openPDF() {
    let DATA = document.getElementById('bill')!;
    html2canvas(DATA).then(canvas => {
    let fileWidth = 200;
    let fileHeight = canvas.height * fileWidth / canvas.width;
    const FILEURI = canvas.toDataURL('image/png')
    let PDF = new jsPDF('p', 'mm', 'a4');
    let positionX = 5;
    let positionY = 4;
    PDF.addImage(FILEURI, 'PNG', positionX, positionY, fileWidth, fileHeight,)
    PDF.save('angular-demo.pdf');
    });
    }

}





























