import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PagerService } from 'src/app/Generic/pager.service';
import { BillGenerationRequest, BillRequest } from 'src/app/Model/bill';
import { Region, Town } from 'src/app/Model/city';
import { CustomerResponse, CustomerResquest, timeframe } from 'src/app/Model/customer';
import { MonthResponse, YearRequest, YearResponse } from 'src/app/Model/shared';
import { BillingService } from 'src/app/Services/billing.service';
import { CityService } from 'src/app/Services/city.service';
import { CustomerService } from 'src/app/Services/customer.service';
import { SharedService } from 'src/app/Services/shared.service';

@Component({
  selector: 'app-bill-generation',
  templateUrl: './bill-generation.component.html',
  styleUrls: ['./bill-generation.component.css']
})
export class BillGenerationComponent implements OnInit {
  page: any ;
  pager: any={}
  pagesize: number = 50;
  totalpages: string = "1";
  dataset: any[] = [];
  objCustomerResponseOrignal: CustomerResponse[]
  objCustomerResponse: CustomerResponse[]
  objCustomerResponse2: CustomerResponse[];
  dataset2: any[] = [];
  RQ_CustomerResquest:CustomerResquest
  RS_Town :Town[]
  RS_Region:Region[]
  checbox:boolean=true
  RS_Month:MonthResponse
  RS_Year:YearResponse
  RQ_Bill:BillRequest
  RQ_Bill_Generation:BillGenerationRequest
  town_count:number
  bill_count:number
  showLoader:boolean=false
  noRecord:boolean=true
  constructor(
  private _BillingService:BillingService,  
  private _CustomerService :CustomerService,
  private _CityService:CityService,
  private router : Router,
  private pagerService: PagerService,
  private _SharedService:SharedService
  ) {
  this.objCustomerResponseOrignal=[]
  this.objCustomerResponse=[]
  this.objCustomerResponse2=[]
  this.RQ_CustomerResquest=new CustomerResquest();
  this.RQ_Bill=new BillRequest();
  this.RQ_Bill_Generation=new BillGenerationRequest() 
  this.RS_Town=[]
  this.RS_Region=[]
  }
  ngOnInit(): void {
  this.GetTown();
  this.GetRegion();
  this.GetMonth();
  this.GetYear();
  }

  GetCustomerByCeiteria(RQ:CustomerResquest)
  {
     this.showLoader=true
    this._CustomerService.GetCustomerByCeiteria(RQ).subscribe(data=>{
      if(data)
      {
        this.showLoader=false
        this.noRecord=false
      this.objCustomerResponseOrignal=JSON.parse(JSON.stringify(data))
       this.bill_count=this.objCustomerResponseOrignal.length
      setTimeout(() => {
        this.setPage(1,this.pagesize)
        }, 20);
      }
      })
  }

  setPage(pages: any, pagesize: any ) {
  
  if ((pages < 1 || pages > this.pager.totalPages) && pages != "") {
  this.page = 1;
  pages = 1;
  }
  this.page = pages;
  this.objCustomerResponse2 = this.objCustomerResponse.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }
  
  GetTown()
  {
    this._CityService.GetTown().subscribe(data=>{
      this.RS_Town=JSON.parse(JSON.stringify(data))
      this.town_count=this.RS_Town.length
    
    })
  }

  GetRegion()
  {
  
    this._CityService.GetRegion().subscribe(data=>{
         this.RS_Region= JSON.parse(JSON.stringify(data))
        //  this.region_count=this.RS_Region.length
    })
  }

  GenerateBillTownWise()
  { 
    if(
          this.RQ_Bill.bill_month!=undefined 
       && this.RQ_Bill.bill_year !=undefined
       && this.RQ_Bill.bill_month!='' 
       && this.RQ_Bill.bill_year !=''
       && this.RQ_Bill.bill_month!='All' 
       && this.RQ_Bill.bill_year !='All'


         )
    {
      this.RQ_Bill_Generation.customer_id=this.RQ_CustomerResquest.customer_id
      this.RQ_Bill_Generation.region_id=this.RQ_CustomerResquest.region_id
      this.RQ_Bill_Generation.town_id=this.RQ_CustomerResquest.town_id

      this.RQ_Bill_Generation.bill_month=this.RQ_Bill.bill_month;
      this.RQ_Bill_Generation.bill_year=this.RQ_Bill.bill_year;

      console.log(this.RQ_Bill_Generation)

      this._BillingService.GenerateBillTownWise(this.RQ_Bill_Generation).subscribe(data=>{
      alert(data)
    })
      
    } 
    else{
      alert("Plese select the month/year first")
    }

      
      
    //}
    // else{
    //   alert("Please select Year and Month")
    // }
  
    
    // this._BillingService.GenerateBillTownWise(RQ).subscribe(data=>{
    //   alert(data)
    // })
    // if(RQ.town_id<=0 || RQ.town_id==undefined )
    // {
    //   alert('Select the town first')
     
    // }
    // if(RQ.bill_month =='' ||  RQ.bill_month == undefined || RQ.bill_year =='' ||  RQ.bill_year == undefined  )
    // {
    //   alert('Select the  Correct moth or year')
      
      
    // }

  }

  GetMonth()
  {
    this._SharedService.GetMonth().subscribe(data=>{
      this.RS_Month=data
    })
  }

  GetYear()
  {
    this._SharedService.GetYear().subscribe(data=>{
      this.RS_Year=data;
    })
  }

  
  }
  